This app does not collect any personal data that is within its control.
